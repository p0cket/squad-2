let creatureIdCounter = 0

export const generateUniqueId = () => {
  return creatureIdCounter++
}

export const creatureUniqueCreature = (creatureTemplate) => {
  return {
    ...creatureTemplate,
    ID: generateUniqueId(),
  }
}
// we need a function that can take a creature template and return a unique creature.
// export const CREATURES = {
//   dragon: {
//     name: "🐉",
//     icon: "🐉",
//     template: "dragon",
//     health: MAX_HP,
//     maxHealth: MAX_HP,
//     attack: 20,
//     trueDamage: 30,
//     defence: 5,
//     mods: [],
//   },

// Now we need a function that creates a full party of unique creatures.
// We pass in an array of creature templates like [CREATURES.dragon, CREATURES.unicorn]
export const createUniqueParty = (creatureTemplates) => {
  return creatureTemplates.map((template) => {
    return creatureUniqueCreature(template)
  })
}
