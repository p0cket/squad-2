// Level Generator Configurations

import { CREATURES } from "../consts/creatures"


// const availableMods = [
//   { name: "Burn", type: "statusEffect", duration: 3, damagePerTurn: 5 },
//   { name: "Regeneration", type: "statusEffect", duration: 3, healPerTurn: 5 },
//   { name: "Stun", type: "statusEffect", duration: 2, preventsAttack: true },
// ]
// Auras (passive effects that apply automatically or enhance the creature's abilities)
export const auras = {
  curseOfCombustion: {
    name: "Curse of Combustion",
    effect: "Burn",
    type: "statusEffect",
    duration: 3,
    damagePerTurn: 5,
    description: "Applies a burning effect to the enemy for 3 turns.",
  },
  tranquility: {
    name: "Tranquility",
    effect: "Regeneration",
    type: "statusEffect",
    duration: 3,
    healPerTurn: 5,
    description: "Heals the creature for 5 health per turn for 3 turns.",
  },
  furyOfTheStorm: {
    name: "Fury of the Storm",
    effect: "Increased Attack",
    type: "buff",
    attackBoost: 10,
    description: "Increases attack by 10 for the duration of the battle.",
  },
}

// Buffs (positive effects that enhance the creature's abilities)
export const buffs = {
  strengthSurge: {
    name: "Strength Surge",
    effect: "Increases Attack",
    type: "buff",
    duration: 5,
    attackBoost: 10,
    description: "Boosts the creature's attack by 10 for 5 turns.",
  },
  shieldOfValor: {
    name: "Shield of Valor",
    effect: "Increases Defense",
    type: "buff",
    duration: 5,
    defenseBoost: 10,
    description: "Boosts the creature's defense by 10 for 5 turns.",
  },
}

// Debuffs (negative effects applied to enemies to weaken them)
export const debuffs = {
  adhd: {
    name: "ADHD",
    effect: "Stun",
    type: "statusEffect",
    duration: 2,
    preventsAttack: true,
    description: "Prevents the enemy from attacking for 2 turns.",
  },
  shadowCurse: {
    name: "Shadow Curse",
    effect: "Reduce Defense",
    type: "debuff",
    duration: 3,
    defenseReduction: 5,
    description: "Reduces the enemy's defense by 5 for 3 turns.",
  },
}

// Combine auras, buffs, and debuffs into availableMods
export const availableMods = [
  ...Object.values(auras),
  ...Object.values(buffs),
  ...Object.values(debuffs),
]

const availableRunes = [
  {
    name: "Rune of Strength",
    effect: "Increases attack by 10",
    statEffect: { stat: "attack", value: 10 },
  },
  {
    name: "Rune of Vitality",
    effect: "Increases health by 20",
    statEffect: { stat: "health", value: 20 },
  },
]

const levelEffects = [
  { name: "Double Damage", effect: "All damage is doubled" },
  { name: "No Healing", effect: "Healing is disabled" },
]

// const scaleStat = (baseValue, level, scaleFactor = 1.05) => {
//   return Math.floor(baseValue * Math.pow(scaleFactor, level))
// }

// Make sure to export the generateLevels function
// Level Generator Function with Thematic Mods

const scaleStat = (baseValue, level, scaleFactor = 1.05) => {
  return Math.floor(baseValue * Math.pow(scaleFactor, level));
};

// Level Generator Function using the central `creatures` object
export const generateLevels = (numLevels) => {
  const levels = [];

  for (let i = 1; i <= numLevels; i++) {
    const numberOfCreatures = Math.floor(Math.random() * 3) + 1; // 1 to 3 creatures per level
    const opponentCreatures = [];

    for (let j = 0; j < numberOfCreatures; j++) {
      // Randomly select a creature from the `creatures` object
      const creatureKeys = Object.keys(CREATURES); // ["dragon", "unicorn", "alien", "fish"]
      const randomCreatureKey = creatureKeys[Math.floor(Math.random() * creatureKeys.length)];
      const randomCreature = { ...CREATURES[randomCreatureKey] }; // Deep copy the selected creature

      // Scale creature stats based on level (exponential scaling)
      randomCreature.health = scaleStat(randomCreature.health, i);
      randomCreature.attack = scaleStat(randomCreature.attack, i);
      randomCreature.defence = scaleStat(randomCreature.defence, i);

      // Apply thematic mods to creatures (auras, buffs, debuffs)
      const randomAura = Object.values(auras)[Math.floor(Math.random() * Object.values(auras).length)];
      const randomBuff = Object.values(buffs)[Math.floor(Math.random() * Object.values(buffs).length)];
      const randomDebuff = Object.values(debuffs)[Math.floor(Math.random() * Object.values(debuffs).length)];

      randomCreature.mods = [randomAura, randomBuff, randomDebuff]; // Assign random mods

      opponentCreatures.push(randomCreature); // Add the configured creature to the opponent list
    }

    // Scale the number of runes and mods based on level difficulty
    const randomRunes = availableRunes.slice(0, Math.floor(Math.random() * availableRunes.length) + 1);
    const randomLevelEffects = levelEffects.slice(0, Math.floor(Math.random() * levelEffects.length) + 1);

    // Push level details to the `levels` array
    levels.push({
      levelNumber: i,
      opponentCreatures,
      opponentRunes: randomRunes,
      levelEffects: randomLevelEffects,
    });
  }

  return levels;
};


// Generate 10 Levels with Scaling
const levels = generateLevels(10)
console.log(levels)
